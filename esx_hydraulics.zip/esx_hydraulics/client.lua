ESX = nil

Citizen.CreateThread(function()
    while ESX == nil do
        TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
        Citizen.Wait(0)
    end
end)

RegisterNetEvent('applyHydraulics')
AddEventHandler('applyHydraulics', function(vehicle)
    -- Code to apply hydraulics to the specified vehicle
end)

