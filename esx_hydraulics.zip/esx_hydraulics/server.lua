ESX = nil

TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)

ESX.RegisterUsableItem('hydraulics', function(source)
    local xPlayer = ESX.GetPlayerFromId(source)
    xPlayer.removeInventoryItem('hydraulics', 1)
    TriggerClientEvent('applyHydraulics', source, GetVehiclePedIsUsing(GetPlayerPed(source)))
end)

ESX.RegisterServerCallback('getHydraulics', function(source, cb)
    local xPlayer = ESX.GetPlayerFromId(source)
    local hydraulics = xPlayer.getInventoryItem('hydraulics')
    cb(hydraulics.count)
end)
